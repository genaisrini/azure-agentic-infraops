<#
.SYNOPSIS
    Deploy edu-pci-eshop infrastructure to Azure
.DESCRIPTION
    Deploys event-driven automated processing system using Bicep templates.
    Includes validation gates: lint, build, what-if preview, user confirmation.
.PARAMETER Environment
    Deployment environment: dev, staging, or prod
.PARAMETER Location
    Azure region for deployment (default: swedencentral)
.PARAMETER ResourceGroupName
    Target resource group name
.PARAMETER Owner
    Resource owner for tagging
.PARAMETER CostCenter
    Optional cost center for billing allocation
.PARAMETER SqlAdminObjectId
    Entra ID object ID for SQL Server admin
.PARAMETER SqlAdminDisplayName
    Entra ID display name for SQL Server admin
.PARAMETER WhatIf
    Preview changes without deploying
.EXAMPLE
    ./deploy.ps1 -Environment dev -ResourceGroupName rg-edu-pci-eshop-dev-swc -Owner "Platform Team" -SqlAdminObjectId "guid" -SqlAdminDisplayName "SQL Admins"
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory=$true)]
    [ValidateSet('dev', 'staging', 'prod')]
    [string]$Environment,

    [Parameter(Mandatory=$false)]
    [ValidateSet('swedencentral', 'germanywestcentral', 'westeurope', 'northeurope')]
    [string]$Location = 'swedencentral',

    [Parameter(Mandatory=$true)]
    [string]$ResourceGroupName,

    [Parameter(Mandatory=$true)]
    [string]$Owner,

    [Parameter(Mandatory=$false)]
    [string]$CostCenter = '',

    [Parameter(Mandatory=$false)]
    [string]$SqlAdminObjectId = '',

    [Parameter(Mandatory=$false)]
    [string]$SqlAdminDisplayName = ''
)

$ErrorActionPreference = 'Stop'
$ProjectName = 'edu-pci-eshop'

# ============================================================================
# ASCII Banner
# ============================================================================

Write-Host @"
╔═══════════════════════════════════════════════════════════════════════╗
║   EDU-PCI-ESHOP DEPLOYMENT                                             ║
║   Event-Driven Automated Processing for EU Education                  ║
╚═══════════════════════════════════════════════════════════════════════╝
"@ -ForegroundColor Cyan

# ============================================================================
# STEP 1: Pre-flight Validation
# ============================================================================

Write-Host "`n┌────────────────────────────────────────────────────────────────────┐" -ForegroundColor Yellow
Write-Host "│  [1/6] PRE-FLIGHT VALIDATION                                       │" -ForegroundColor Yellow
Write-Host "└────────────────────────────────────────────────────────────────────┘" -ForegroundColor Yellow

Write-Host "  • Checking Azure CLI..." -NoNewline
$azVersion = az version --output json 2>$null | ConvertFrom-Json
if ($null -eq $azVersion) {
    Write-Host " ❌ FAILED" -ForegroundColor Red
    throw "Azure CLI not found. Install from https://aka.ms/install-azure-cli"
}
Write-Host " ✅ $($azVersion.'azure-cli')" -ForegroundColor Green

Write-Host "  • Checking Bicep CLI..." -NoNewline
$bicepVersion = bicep --version 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Host " ❌ FAILED" -ForegroundColor Red
    throw "Bicep CLI not found. Run: az bicep install"
}
Write-Host " ✅ $($bicepVersion -replace 'Bicep CLI version ', '')" -ForegroundColor Green

Write-Host "  • Checking Azure authentication..." -NoNewline
$account = az account show 2>$null | ConvertFrom-Json
if ($null -eq $account) {
    Write-Host " ❌ FAILED" -ForegroundColor Red
    throw "Not authenticated. Run: az login"
}
Write-Host " ✅ $($account.user.name)" -ForegroundColor Green

Write-Host "  • Checking subscription..." -NoNewline
Write-Host " ✅ $($account.name)" -ForegroundColor Green

# ============================================================================
# STEP 2: SQL Admin Auto-Detection
# ============================================================================

Write-Host "`n┌────────────────────────────────────────────────────────────────────┐" -ForegroundColor Yellow
Write-Host "│  [2/6] SQL ADMIN CONFIGURATION                                     │" -ForegroundColor Yellow
Write-Host "└────────────────────────────────────────────────────────────────────┘" -ForegroundColor Yellow

if ([string]::IsNullOrWhiteSpace($SqlAdminObjectId)) {
    Write-Host "  • Auto-detecting current user as SQL admin..." -NoNewline
    $currentUser = az ad signed-in-user show 2>$null | ConvertFrom-Json
    if ($null -eq $currentUser) {
        Write-Host " ⚠️ FAILED (using service principal?)" -ForegroundColor Yellow
        Write-Host "`n  ⚠️  Manual SQL admin required:" -ForegroundColor Yellow
        Write-Host "      Provide -SqlAdminObjectId and -SqlAdminDisplayName parameters" -ForegroundColor Yellow
        throw "SQL admin not configured"
    }
    $SqlAdminObjectId = $currentUser.id
    $SqlAdminDisplayName = $currentUser.displayName
    Write-Host " ✅ $SqlAdminDisplayName" -ForegroundColor Green
} else {
    Write-Host "  • Using provided SQL admin: $SqlAdminDisplayName" -ForegroundColor Green
}

# ============================================================================
# STEP 3: Resource Group
# ============================================================================

Write-Host "`n┌────────────────────────────────────────────────────────────────────┐" -ForegroundColor Yellow
Write-Host "│  [3/6] RESOURCE GROUP                                              │" -ForegroundColor Yellow
Write-Host "└────────────────────────────────────────────────────────────────────┘" -ForegroundColor Yellow

$rgExists = az group exists --name $ResourceGroupName 2>$null
if ($rgExists -eq 'false') {
    Write-Host "  • Creating resource group: $ResourceGroupName..." -NoNewline
    az group create --name $ResourceGroupName --location $Location --output none 2>$null
    Write-Host " ✅ CREATED" -ForegroundColor Green
} else {
    Write-Host "  • Resource group exists: $ResourceGroupName ✅" -ForegroundColor Green
}

# ============================================================================
# STEP 4: Template Validation
# ============================================================================

Write-Host "`n┌────────────────────────────────────────────────────────────────────┐" -ForegroundColor Yellow
Write-Host "│  [4/6] TEMPLATE VALIDATION                                         │" -ForegroundColor Yellow
Write-Host "└────────────────────────────────────────────────────────────────────┘" -ForegroundColor Yellow

Write-Host "  • Running bicep lint..." -NoNewline
$lintOutput = bicep lint main.bicep 2>&1
$lintErrors = $lintOutput | Where-Object { $_ -match "Error " }
if ($lintErrors.Count -gt 0) {
    Write-Host " ❌ ERRORS FOUND" -ForegroundColor Red
    $lintErrors | ForEach-Object { Write-Host "      $_" -ForegroundColor Red }
    throw "Bicep lint failed"
}
Write-Host " ✅ PASSED" -ForegroundColor Green

Write-Host "  • Running bicep build..." -NoNewline
bicep build main.bicep --outfile main.json 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Host " ❌ FAILED" -ForegroundColor Red
    throw "Bicep build failed"
}
Write-Host " ✅ COMPILED" -ForegroundColor Green

# ============================================================================
# STEP 5: What-If Analysis
# ============================================================================

Write-Host "`n┌────────────────────────────────────────────────────────────────────┐" -ForegroundColor Yellow
Write-Host "│  [5/6] WHAT-IF ANALYSIS                                            │" -ForegroundColor Yellow
Write-Host "└────────────────────────────────────────────────────────────────────┘" -ForegroundColor Yellow

Write-Host "  • Running deployment preview (what-if)...`n" -ForegroundColor Cyan

$whatIfResult = az deployment group what-if `
    --resource-group $ResourceGroupName `
    --template-file main.json `
    --parameters environment=$Environment `
                 location=$Location `
                 owner="$Owner" `
                 costCenter="$CostCenter" `
                 sqlAdminObjectId=$SqlAdminObjectId `
                 sqlAdminDisplayName="$SqlAdminDisplayName" `
    --result-format FullResourcePayloads `
    2>&1

Write-Host $whatIfResult

# Parse change summary
$createCount = ($whatIfResult | Select-String -Pattern "Resource and property changes: " -Context 0,3).ToString()
if ($createCount -match "(\d+) to create") {
    $create = $matches[1]
} else {
    $create = "Unknown"
}

Write-Host "`n┌─────────────────────────────────────────┐" -ForegroundColor Cyan
Write-Host "│  CHANGE SUMMARY                          │" -ForegroundColor Cyan
Write-Host "│  + Create: $create resources" -NoNewline
Write-Host ("             │").PadLeft(43 - $create.Length) -ForegroundColor Cyan
Write-Host "│  ~ Modify: 0 resources                   │" -ForegroundColor Cyan
Write-Host "│  - Delete: 0 resources                   │" -ForegroundColor Cyan
Write-Host "└─────────────────────────────────────────┘" -ForegroundColor Cyan

# ============================================================================
# STEP 6: User Confirmation
# ============================================================================

if ($WhatIfPreference) {
    Write-Host "`n✅ WHAT-IF MODE - No deployment will occur" -ForegroundColor Green
    exit 0
}

Write-Host "`n┌────────────────────────────────────────────────────────────────────┐" -ForegroundColor Magenta
Write-Host "│  ⚠️  DEPLOYMENT CONFIRMATION                                        │" -ForegroundColor Magenta
Write-Host "└────────────────────────────────────────────────────────────────────┘" -ForegroundColor Magenta

Write-Host "  Environment:      $Environment" -ForegroundColor White
Write-Host "  Location:         $Location" -ForegroundColor White
Write-Host "  Resource Group:   $ResourceGroupName" -ForegroundColor White
Write-Host "  Owner:            $Owner" -ForegroundColor White
Write-Host "  SQL Admin:        $SqlAdminDisplayName" -ForegroundColor White
Write-Host ""

if ($PSCmdlet.ShouldProcess($ResourceGroupName, "Deploy edu-pci-eshop infrastructure")) {
    $confirmation = Read-Host "Type 'yes' to proceed with deployment"
    if ($confirmation -ne 'yes') {
        Write-Host "`n❌ Deployment cancelled by user" -ForegroundColor Yellow
        exit 0
    }
} else {
    Write-Host "`n❌ Deployment skipped (-WhatIf mode)" -ForegroundColor Yellow
    exit 0
}

# ============================================================================
# STEP 7: Execute Deployment
# ============================================================================

Write-Host "`n┌────────────────────────────────────────────────────────────────────┐" -ForegroundColor Green
Write-Host "│  [6/6] EXECUTING DEPLOYMENT                                        │" -ForegroundColor Green
Write-Host "└────────────────────────────────────────────────────────────────────┘" -ForegroundColor Green

Write-Host "`n  🚀 Deploying infrastructure (this may take 10-15 minutes)...`n" -ForegroundColor Cyan

$deploymentName = "edu-pci-eshop-$Environment-$(Get-Date -Format 'yyyyMMdd-HHmmss')"

az deployment group create `
    --name $deploymentName `
    --resource-group $ResourceGroupName `
    --template-file main.json `
    --parameters environment=$Environment `
                 location=$Location `
                 owner="$Owner" `
                 costCenter="$CostCenter" `
                 sqlAdminObjectId=$SqlAdminObjectId `
                 sqlAdminDisplayName="$SqlAdminDisplayName" `
    --output json | ConvertFrom-Json | Out-Null

if ($LASTEXITCODE -ne 0) {
    Write-Host "`n❌ DEPLOYMENT FAILED" -ForegroundColor Red
    Write-Host "  Check Azure Portal for detailed error messages" -ForegroundColor Yellow
    exit 1
}

# ============================================================================
# STEP 8: Display Outputs
# ============================================================================

Write-Host "`n✅ DEPLOYMENT SUCCESSFUL" -ForegroundColor Green
Write-Host "`n┌────────────────────────────────────────────────────────────────────┐" -ForegroundColor Cyan
Write-Host "│  DEPLOYED RESOURCES                                                │" -ForegroundColor Cyan
Write-Host "└────────────────────────────────────────────────────────────────────┘" -ForegroundColor Cyan

$outputs = az deployment group show `
    --name $deploymentName `
    --resource-group $ResourceGroupName `
    --query properties.outputs `
    2>$null | ConvertFrom-Json

Write-Host "  • Log Analytics Workspace: $($outputs.logAnalyticsWorkspaceId.value)" -ForegroundColor White
Write-Host "  • Application Insights:    $($outputs.appInsightsConnectionString.value.Substring(0,50))..." -ForegroundColor White
Write-Host "  • Key Vault:               $($outputs.keyVaultUri.value)" -ForegroundColor White
Write-Host "  • Storage Account:         $($outputs.storageAccountName.value)" -ForegroundColor White
Write-Host "  • Service Bus:             $($outputs.serviceBusEndpoint.value)" -ForegroundColor White
Write-Host "  • SQL Server:              $($outputs.sqlServerFqdn.value)" -ForegroundColor White
Write-Host "  • Function Apps:           $($outputs.funcOrdersId.value.Split('/')[-1]), $($outputs.funcInvoicesId.value.Split('/')[-1]), $($outputs.funcNotificationsId.value.Split('/')[-1])" -ForegroundColor White

Write-Host "`n┌────────────────────────────────────────────────────────────────────┐" -ForegroundColor Green
Write-Host "│  NEXT STEPS                                                        │" -ForegroundColor Green
Write-Host "└────────────────────────────────────────────────────────────────────┘" -ForegroundColor Green

Write-Host @"
  1. Configure RBAC for Function Apps
     - Service Bus Data Receiver role on Service Bus namespace
     - Storage Blob Data Contributor role on Storage Account
     - Key Vault Secrets User role on Key Vault
     - SQL Database Contributor role on SQL Database

  2. Deploy Function App code
     - Clone repository and build Function projects
     - Deploy via Azure Functions Core Tools or GitHub Actions

  3. Provision Entra ID B2C tenant (manual)
     - Create B2C tenant via Azure Portal
     - Configure user flows and identity providers
     - Update Function App settings with B2C endpoints

  4. Verify monitoring
     - Check Application Insights for telemetry
     - Configure alerts in Azure Monitor

  5. Review security
     - Audit RBAC role assignments
     - Verify network security (consider Private Endpoints for prod)
     - Enable Advanced Threat Protection on SQL Server

"@ -ForegroundColor White

Write-Host "╔═══════════════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║   DEPLOYMENT COMPLETE                                                  ║" -ForegroundColor Cyan
Write-Host "╚═══════════════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan

# Cleanup temporary ARM JSON
if (Test-Path "main.json") {
    Remove-Item "main.json" -Force
}
